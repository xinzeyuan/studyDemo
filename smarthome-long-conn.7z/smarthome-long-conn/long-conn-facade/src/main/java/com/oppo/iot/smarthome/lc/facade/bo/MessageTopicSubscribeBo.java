package com.oppo.iot.smarthome.lc.facade.bo;

import lombok.Data;

import java.util.List;

/**
 * 长连接消息主题信息
 * @author 80279309
 */
@Data
public class MessageTopicSubscribeBo implements java.io.Serializable {

    private String ssoid;
    private String clientId;
    private List<String> topic;
}
