package com.oppo.iot.smarthome.lc.facade.bo;

// 对外实体