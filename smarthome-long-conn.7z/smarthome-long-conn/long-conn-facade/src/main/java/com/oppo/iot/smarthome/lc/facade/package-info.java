package com.oppo.iot.smarthome.lc.facade;

// 对外接口包

/*
-|---bo 对外传输数据实体包
  ---enum 提供给外部的枚举
  ---exception 提供给外部的异常
  ---facade 提供的外部的综合性接口
*/