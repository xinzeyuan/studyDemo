package com.oppo.iot.smarthome.lc.facade.bo;

import lombok.Data;

import java.util.Date;

/**
 * 长连接客户端设备连接id的基本信息
 */
@Data
public class UserClientBo implements java.io.Serializable {

    private String ssoid;

    private String clientId;

    private String appVersion;

    private Date createTime;

    private Date updateTime;
}
