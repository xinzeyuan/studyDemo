package com.oppo.iot.smarthome.lc.facade.api;

import com.oppo.iot.smarthome.lc.facade.bo.UserClientBo;

/**
 * 长连接管理接口
 * @author 80279309
 */
public interface ConnectionManageFacade {

    /**
     * 客户端注册链接信息
     * @param userClientBo 链接信息
     * @return 注册成功返回true
     */
    Boolean registerConn(UserClientBo userClientBo);

    /**
     * 取消注册信息
     * @param userClientBo
     * @return 取消成功返回true
     */
    Boolean cancelConn(UserClientBo userClientBo);


    /**
     * 通道是否可用，此时相当于通过后端的心跳 告诉客户端  推送服务和 长连接中间件是否可用
     * @param ssoId
     * @param clientId
     * @return 可用返回true
     */
    Boolean isChannelHealth(String ssoId, String clientId);
}
