package com.oppo.iot.smarthome.lc.facade.exception;

// 对外异常