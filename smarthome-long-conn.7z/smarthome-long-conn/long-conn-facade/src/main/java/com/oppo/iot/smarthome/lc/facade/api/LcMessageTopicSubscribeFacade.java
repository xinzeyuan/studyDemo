package com.oppo.iot.smarthome.lc.facade.api;

import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;

/**
 * 消息主题订阅关系对外接口
 * @author 80279309
 */
public interface LcMessageTopicSubscribeFacade {

    /**
     * 订阅主题
     * @param subscribeBo
     * @return
     */
    boolean subscribe(MessageTopicSubscribeBo subscribeBo);

    /**
     * 取消订阅某个主题
     * @param subscribeBo
     * @return
     */
    boolean unsubscribe(MessageTopicSubscribeBo subscribeBo);

}
