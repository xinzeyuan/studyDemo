package com.oppo.iot.smarthome.lc.cache.redis;

import org.apache.commons.lang.StringUtils;

/**
 * cache key 常量
 *
 * @author 80279309
 */
public enum RedisKeys {

    /**
     * 用户连接管理 prefix+ssoid
     */
    USER_CLIENT_PREFIX("iot:long_conn:user_client:"),

    /**
     * 用户，客户端与订阅的消息主题 prefix+ssoid
     */
    USER_CLIENT_ID_TOPIC_PREFIX("iot:long_conn:ssoid:"),

    /**
     * 消息主题
     */
    MESSAGE_TOPIC("iot:long_conn:message_topic:"),

    /**
     * user 与 client 键值对   prefix+ssoid
     */
    USER_CLIENT_CLIENT_IDS_PREFIX("iot:long_conn:user_client_client_ids:"),

    /**
     * 发送出去需要确认的消息 key=prefix+msgId
     */
    SENT_MSG_PREFIX("iot:long_conn:sent_msg:"),

    /**
     * 消息消费重试 key=prefix+msgId
     */
    CONSUME_RETRY_PREFIX("iot:long_conn:sent_retry:"),

    /**
     * 客户端心跳 key=prefix+clientId
     */
    CLIENT_HEARTBEAT_PREFIX("iot:long_conn:heartbeat:"),

    /**
     * 长连接中间件状态值
     */
    CONN_CHANNEL_HEALTH_PREFIX("iot:long_conn:health"),

    ;

    private String prefix;

    RedisKeys(String prefix) {
        this.prefix = prefix;
    }


    public static String getKey(RedisKeys redisKeys, String unique) {
        return StringUtils.isBlank(unique) ? redisKeys.prefix : redisKeys.prefix + unique;
    }

    public String getKey(String unique) {
        return StringUtils.isBlank(unique) ? this.prefix : this.prefix + unique;
    }
}
