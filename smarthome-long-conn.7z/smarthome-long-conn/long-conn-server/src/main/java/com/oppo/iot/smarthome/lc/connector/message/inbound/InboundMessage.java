package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

/**
 * 消息基类
 * @author 80279309
 */
@Data
public class InboundMessage implements java.io.Serializable {
    private String msgId;
    private String ssoId;
}
