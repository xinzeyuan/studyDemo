package com.oppo.iot.smarthome.lc.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import java.util.List;

/**
 * JSON的转换类，当前实现为 fastjson ，可以统一修改
 * @author 80279309
 */
public class JSONUtils {

    public static String toJSONString(Object obj) {
        return JSON.toJSONString(obj);
    }

    public static <T> T parseObject(String text, Class<T> clazz) {
        return JSON.parseObject(text, clazz);
    }

    public static  <T> List<T> parseObjectArray(String text, Class<T> clazz) {
        return JSONArray.parseArray(text, clazz);
    }
}
