package com.oppo.iot.smarthome.lc.config;//package com.oppo.iot.admin.platform.web.config;
//
//import com.alibaba.dubbo.config.*;
//import com.oppo.basic.heracles.client.core.spring.annotation.HeraclesDynamicConfig;
//import com.oppo.iot.meta.persistence.service.ProductService;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class DubboConsumerConfig {
//
//    @HeraclesDynamicConfig(fileName="application.properties" , key="dubbo.application.name" , defaultValue = "defaultName")
//    private String applicationName;
//
//    @HeraclesDynamicConfig(fileName="application.properties" , key="dubbo.registry.protocol" , defaultValue = "defaultName")
//    private String registryProtocol;
//
//    @HeraclesDynamicConfig(fileName="application.properties" , key="dubbo.registry.address" , defaultValue = "defaultName")
//    private String registryAddress;
//
//    @Bean
//    public ApplicationConfig applicationConfig() {
//        ApplicationConfig applicationConfig = new ApplicationConfig();
//        applicationConfig.setName(applicationName);
//        return applicationConfig;
//    }
//
//    @Bean
//    public RegistryConfig registryConfig() {
//        RegistryConfig registryConfig = new RegistryConfig();
//        registryConfig.setProtocol(registryProtocol);
//        registryConfig.setAddress(registryAddress);
//        return registryConfig;
//    }
//
//    // 提供者需要
////    @Bean
////    public ProtocolConfig protocolConfig() {
////        ProtocolConfig protocolConfig = new ProtocolConfig();
////        protocolConfig.setName("dubbo");
////        protocolConfig.setPort(20882);
////        return protocolConfig;
////    }
//
//    @Bean
//    public ProductService productService(){
//        ReferenceConfig<ProductService> config = new ReferenceConfig<>();
//        config.setApplication(applicationConfig());
//        config.setRegistry(registryConfig());
//        config.setInterface(ProductService.class);
//        config.setVersion("1.0.2");
//        return config.get();
//    }
//
//
//}
