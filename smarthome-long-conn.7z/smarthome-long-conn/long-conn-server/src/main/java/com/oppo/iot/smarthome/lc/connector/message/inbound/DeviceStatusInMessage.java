package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

import java.util.Map;

/**
 * 设备状态信息
 *
 * @author 80279309
 */
@Data
public class DeviceStatusInMessage extends InboundMessage {

    private String deviceId;
    private Map<String, Object> properties;
    private String status;
}
