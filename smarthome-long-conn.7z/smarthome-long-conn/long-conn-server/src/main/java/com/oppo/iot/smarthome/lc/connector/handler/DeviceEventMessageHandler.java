package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.DeviceEventInMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.DeviceEventOutMessage;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * todo-yh: 事件消息是否需要改动
 * @author 80279309
 */
@Slf4j
@Component
public class DeviceEventMessageHandler extends AbstractMessageHandler<DeviceEventInMessage, DeviceEventOutMessage>{


    @Override
    public boolean isMatch(String topic) {
        return MqTopic.DEVICE_EVENT_TOPIC.equals(topic);
    }

    @Override
    public DeviceEventInMessage decode(String message) {
        if (message == null) {
            return null;
        }
        return JSONUtils.parseObject(message, DeviceEventInMessage.class);
    }

    @Override
    public DeviceEventOutMessage handle(DeviceEventInMessage inMessage, String topic) {
        log.info("event inbound message={}", JSONUtils.toJSONString(inMessage));
        
        DeviceEventOutMessage out = new DeviceEventOutMessage();
        out.setDialogInfoId("dialogId01");
        out.setSsoId(inMessage.getSsoId());
        out.setMsgId(inMessage.getMsgId());
        return out;
    }

}
