package com.oppo.iot.smarthome.lc.service;

import com.oppo.iot.smarthome.lc.model.MessageTopic;

/**
 * 消息主题管理，数据插入数据，没有做管理界面，所以暂时只提供查询接口
 * @author 80279309
 */
public interface MessageTopicService {

     /**
     * 查询主题信息，带缓存
     * @param topic
     * @return
     */
    MessageTopic getByCode(String topic);
}
