package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @author 80279309
 *
 */
@Data
public class DeviceStatusOutMessage extends OutBoundMessage {

    private String deviceId;
    private List<DeviceStatusProperty> deviceProperties;

    @Data
    @Builder
    public static class DeviceStatusProperty {
        private String property;
        private Object value;
        private String description;
        private int position;
    }
}
