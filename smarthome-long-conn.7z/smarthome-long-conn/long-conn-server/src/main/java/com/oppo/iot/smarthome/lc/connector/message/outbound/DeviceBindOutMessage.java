package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Data;

import java.util.Date;

/**
 * 配网结果消息
 * @author 80279309
 */
@Data
public class DeviceBindOutMessage extends OutBoundMessage {

    private String bindKey;
    private String deviceId;
    private long homeAddr;
    /**
     * 成功失败标志
     */
    private int result;
    private Date bindTime;
}
