package com.oppo.iot.smarthome.lc.service;

import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;

import java.util.List;

/**
 * 消息订阅关系管理
 * @author 80279309
 */
public interface MessageTopicSubscribeService {

    /**
     * 订阅主题
     * @param ssoid
     * @param clientId
     * @param topic
     * @return
     */
    boolean subscribe(String ssoid, String clientId, List<String> topic);

    /**
     * 取消订阅某个主题
     * @param ssoid
     * @param clientId
     * @param topic
     * @return
     */
    boolean unsubscribe(String ssoid, String clientId, List<String> topic);


    /**
     * 取消订阅指定clientId的所有主题
     * @param ssoid
     * @param clientId
     * @return
     */
    boolean unsubscribe(String ssoid, String clientId);


    /**
     * 获取用户订阅的topic
     * @param ssoid 用户id必填
     * @param ssoid 选填
     * @return
     */
    List<MessageTopicSubscribeBo> userTopic(String ssoid);
}
