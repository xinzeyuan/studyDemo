package com.oppo.iot.smarthome.lc.facade.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.oppo.iot.smarthome.lc.facade.api.LcMessageTopicSubscribeFacade;
import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;

/**
 * @author 80279309
 */
@Slf4j
@Service
public class LcMessageTopicSubscribeFacadeImpl implements LcMessageTopicSubscribeFacade {

    @Autowired
    private  MessageTopicSubscribeService messageTopicSubscribeService;

    @Override
    public boolean subscribe(MessageTopicSubscribeBo subscribeBo) {
        log.info("subscribe params={}", subscribeBo);
        // 参数校验
        boolean isInvalidParams = subscribeBo == null
                || StringUtils.isBlank(subscribeBo.getSsoid())
                || StringUtils.isBlank(subscribeBo.getClientId())
                || CollectionUtils.isEmpty(subscribeBo.getTopic());
        if (isInvalidParams) {
            return false;
        }

        // 订阅
        boolean subscribe = messageTopicSubscribeService.subscribe(subscribeBo.getSsoid(), subscribeBo.getClientId(), subscribeBo.getTopic());
        return subscribe;
    }

    @Override
    public boolean unsubscribe(MessageTopicSubscribeBo subscribeBo) {
        log.info("unsubscribe params={}", subscribeBo);
        // 参数校验
        boolean isInvalidParams = subscribeBo == null
                || StringUtils.isBlank(subscribeBo.getSsoid())
                || StringUtils.isBlank(subscribeBo.getClientId())
                || CollectionUtils.isEmpty(subscribeBo.getTopic());
        if (isInvalidParams) {
            return false;
        }

        // 取消订阅
        boolean unsubscribe = messageTopicSubscribeService.unsubscribe(subscribeBo.getSsoid(), subscribeBo.getClientId(), subscribeBo.getTopic());
        return unsubscribe;
    }

}
