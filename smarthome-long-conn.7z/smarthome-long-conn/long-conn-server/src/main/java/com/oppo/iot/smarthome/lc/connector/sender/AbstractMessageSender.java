package com.oppo.iot.smarthome.lc.connector.sender;

import com.oppo.iot.smarthome.lc.config.ConfigCenter;
import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;
import com.oppo.iot.smarthome.lc.enums.MessageConfirmStatusEnum;
import com.oppo.iot.smarthome.lc.enums.TopicLevelEnum;
import com.oppo.iot.smarthome.lc.model.MessageTopic;
import com.oppo.iot.smarthome.lc.service.MessageConfirmService;
import com.oppo.iot.smarthome.lc.service.MessageTopicService;
import com.oppo.iot.smarthome.lc.connector.DelayTimer;
import io.netty.util.TimerTask;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 消息发送者
 * @author 80279309
 */
@Slf4j
public abstract class AbstractMessageSender implements MessageSender {

    @Autowired
    protected MessageTopicService messageTopicService;

    @Autowired
    protected ConfigCenter configCenter;

    @Autowired
    protected MessageConfirmService messageConfirmService;

    @Override
    public boolean send(CommonOutboundMessage message, String clientId) {
        log.info("send message: {}", message);
        // 获取topic level
        TopicLevelEnum topicLevelEnum = getTopicLevel(message);
        if (topicLevelEnum == null) {
            return false;
        }

        // 发送消息
        boolean rs = doSend(message, clientId);
        if (!rs) {
            return false;
        }

        // 需要确认的消息，缓存确认状态，设置延迟处理器，用来处理消息超时未确认
        if (TopicLevelEnum.MIDDLE_WARE_RESPONSE.equals(topicLevelEnum) || TopicLevelEnum.CLIENT_RESPONSE.equals(topicLevelEnum)) {
            // 缓冲确认状态
            messageConfirmService.saveConfirmStatus(message.getMsgId(), MessageConfirmStatusEnum.NO_CONFIRMED);

            // 添加延迟任务
            TimerTask task = new SendConfirmTimeoutTask(message, clientId, 0, configCenter.getSendMaxRetry(), topicLevelEnum, this, messageConfirmService);
            DelayTimer.addTask(task, configCenter.getSendConfirmTimeout());
        }

        return true;
    }

    @Override
    public boolean retryOnConfirmTimeout(SendConfirmTimeoutTask task) {

        doSend(task.getMessage(), task.getClientId());

        task.setCurrentRetryCount(task.getCurrentRetryCount() + 1);

        DelayTimer.addTask(task, configCenter.getSendConfirmTimeout());

        return true;
    }

    /**
     * 真实调用中间件发送消息
     * @param message
     * @param clientId
     * @return
     */
    protected abstract  boolean doSend(CommonOutboundMessage message, String clientId);


    private TopicLevelEnum getTopicLevel(CommonOutboundMessage message) {
        String topic = message.getTopic();
        MessageTopic messageTopic = messageTopicService.getByCode(topic);
        if (messageTopic != null && messageTopic.getLevel() != null) {
            TopicLevelEnum topicLevelEnum = TopicLevelEnum.getByCode(messageTopic.getLevel());
            return topicLevelEnum;
        }
        return null;
    }

}
