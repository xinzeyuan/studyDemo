package com.oppo.iot.smarthome.lc.service.impl;

import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import com.oppo.iot.smarthome.lc.mapper.UserClientMapper;
import com.oppo.iot.smarthome.lc.model.UserClient;
import com.oppo.iot.smarthome.lc.model.UserClientExample;
import com.oppo.iot.smarthome.lc.service.UserClientService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author 80279309
 */
@Service
public class UserClientServiceImpl implements UserClientService {

    @Autowired
    private UserClientMapper userClientMapper;

    @Autowired
    private RedissonClient redissonClient;

    @Override
    public UserClient add(UserClient userClient) {
        if (userClient == null || StringUtils.isBlank(userClient.getSsoid())) {
            return null;
        }
        Date date = new Date();

        // 是否需要手动id?

        userClient.setCreateTime(userClient.getCreateTime() == null ? date : userClient.getCreateTime());
        int row = userClientMapper.insertSelective(userClient);
        if (row > 0) {
            // 查询当前用户的所有UserClient 更新缓存
            selectAndUpdateCache(userClient.getSsoid());
            return userClient;
        } else {
            return null;
        }
    }

    @Override
    public int remove(UserClient userClient) {
        if (userClient == null) {
            return 0;
        }

        UserClientExample example = new UserClientExample();
        UserClientExample.Criteria criteria = example.createCriteria();
        // 只动态支持需要的条件
        if (userClient.getId() != null) {
            criteria.andIdEqualTo(userClient.getId());
        }
        if (StringUtils.isNotBlank(userClient.getSsoid())) {
            criteria.andSsoidEqualTo(userClient.getSsoid());
        }
        if (StringUtils.isNotBlank(userClient.getClientId())) {
            criteria.andClientIdEqualTo(userClient.getClientId());
        }
        int row = userClientMapper.deleteByExample(example);
        if (row > 0) {
            // 查询当前用户的所有UserClient 更新缓存
            selectAndUpdateCache(userClient.getSsoid());
        }
        return row;
    }

    @Override
    public List<UserClient> listBySsoId(String ssoId) {

        // get from cache
        List<UserClient> list = getFromCache(ssoId);
        if (CollectionUtils.isNotEmpty(list)) {
            return list;
        }

        // get from db and update cache
        return selectAndUpdateCache(ssoId);
    }


    private List<UserClient> getFromCache(String ssoId) {
        String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_PREFIX, ssoId);
        return redissonClient.getList(key);
    }

    private List<UserClient> selectAndUpdateCache(String ssoId) {
        // get from db
        UserClientExample example = new UserClientExample();
        UserClientExample.Criteria criteria = example.createCriteria();
        criteria.andSsoidEqualTo(ssoId);
        List<UserClient> list = userClientMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(list)) {
            return new ArrayList<>();
        }

        // set to cache
        String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_PREFIX, ssoId);
        RBucket<List<UserClient>> bucket = redissonClient.getBucket(key);
        bucket.set(list, 1, TimeUnit.DAYS);

        return list;
    }
}
