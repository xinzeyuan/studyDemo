package com.oppo.iot.smarthome.lc.mapper;

import com.oppo.iot.smarthome.lc.model.MessageTopic;
import com.oppo.iot.smarthome.lc.model.MessageTopicExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MessageTopicMapper {
    int countByExample(MessageTopicExample example);

    int deleteByExample(MessageTopicExample example);

    int deleteByPrimaryKey(Long id);

    int insert(MessageTopic record);

    int insertSelective(MessageTopic record);

    List<MessageTopic> selectByExample(MessageTopicExample example);

    MessageTopic selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") MessageTopic record, @Param("example") MessageTopicExample example);

    int updateByExample(@Param("record") MessageTopic record, @Param("example") MessageTopicExample example);

    int updateByPrimaryKeySelective(MessageTopic record);

    int updateByPrimaryKey(MessageTopic record);
}