package com.oppo.iot.smarthome.lc.connector.health;


import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * 心跳管理
 *
 * @author 80279309
 */
@Component
public class HealthHandler {

    /**
     * 心跳超时时间，单位秒
     */
    public static final long HEARTBEAT_TIMEOUT = 10 * 60;

    @Autowired
    private RedissonClient redissonClient;

    /**
     * 获取客户端最后一次心跳时间
     * @param clientId
     * @return
     */
    public Long getLastBeatTime(String clientId) {
        RBucket<Long> msgBucket = redissonClient.getBucket(RedisKeys.CLIENT_HEARTBEAT_PREFIX.getKey(clientId));
        return msgBucket.get();
    }

    /**
     * 跟新客户端最后一次心跳时间
     * @param clientId
     */
    public void setLastBeatTime(String clientId) {
        RBucket<Long> msgBucket = redissonClient.getBucket(RedisKeys.CLIENT_HEARTBEAT_PREFIX.getKey(clientId));
        msgBucket.set(System.currentTimeMillis(), 1, TimeUnit.MINUTES);
    }

    public boolean isChannelHealth() {
        RBucket<Boolean> msgBucket = redissonClient.getBucket(RedisKeys.CONN_CHANNEL_HEALTH_PREFIX.getKey(null));
        Boolean isBad = msgBucket.get();
        return isBad != null;
    }

    /**
     * todo-yh: 长连接中间件与服务器连接出现异常，捕获异常，设置状态值，恢复后调用删除
     * @param isOk
     */
    public void setChannelHealth(boolean isOk) {
        RBucket<Boolean> msgBucket = redissonClient.getBucket(RedisKeys.CONN_CHANNEL_HEALTH_PREFIX.getKey(null));
        if (isOk) {
            msgBucket.delete();
        } else {
            msgBucket.set(false);
        }
    }

}
