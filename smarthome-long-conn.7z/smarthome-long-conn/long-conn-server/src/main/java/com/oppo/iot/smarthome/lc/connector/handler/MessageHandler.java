package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.InboundMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.OutBoundMessage;

/**
 * 消息处理器
 * 接受消息，根据业务逻辑需要，处理成需要发出的消息
 * @author 80279309
 */
public interface MessageHandler<IN extends InboundMessage, OUT extends OutBoundMessage> {

    /**
     * 是否匹配  匹配的情况才会进入处理器中处理
     * @param topic
     * @return
     */
    boolean isMatch(String topic);

    /**
     * mq的消息转换成业务处理的对象
     * @param message
     * @return
     */
    IN decode(String message);

    /**
     * 处理消息，根据进来的消息，处理到应该发送的消息
     * @param inMessage 接收的消息
     * @return 应该发送的消息，如何不需要发则为null
     */
    OUT handle(IN inMessage, String topic);


    /**
     * 发送消息, 为空不发送
     * @param outMessage
     */
    void send(OUT outMessage, String topic, String key);

    /**
     * 消费出现异常时候的处理类
     * @param message
     * @param topic
     */
    void onInboundException(String message, String  topic, String key, Object listener, Exception e);

    /**
     * 发送出现异常时候的处理类
     * @param message
     * @param topic
     */
    void onOutboundException(OUT message, String  topic, String key, Exception e);
}
