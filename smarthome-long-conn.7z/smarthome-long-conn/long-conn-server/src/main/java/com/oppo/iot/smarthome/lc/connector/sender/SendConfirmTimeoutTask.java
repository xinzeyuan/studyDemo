package com.oppo.iot.smarthome.lc.connector.sender;

import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;
import com.oppo.iot.smarthome.lc.enums.MessageConfirmStatusEnum;
import com.oppo.iot.smarthome.lc.enums.TopicLevelEnum;
import com.oppo.iot.smarthome.lc.service.MessageConfirmService;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * 发送确认超时处理器
 * @author 80279309
 */
@Slf4j
@Data
public class SendConfirmTimeoutTask implements TimerTask {


    private CommonOutboundMessage message;
    private String clientId;

    private int currentRetryCount;
    private int maxRetryCount;
    private TopicLevelEnum topicLevel;

    private MessageSender messageSender;
    private MessageConfirmService messageConfirmService;

    public SendConfirmTimeoutTask(CommonOutboundMessage message, String clientId, int currentRetryCount, int maxRetryCount, TopicLevelEnum topicLevel, MessageSender messageSender, MessageConfirmService messageConfirmService) {
        this.message = message;
        this.clientId = clientId;
        this.currentRetryCount = currentRetryCount;
        this.maxRetryCount = maxRetryCount;
        this.topicLevel = topicLevel;
        this.messageSender = messageSender;
        this.messageConfirmService=messageConfirmService;
    }

    @Override
    public void run(Timeout timeout) throws Exception {
        // 查询确认状态
        MessageConfirmStatusEnum statusEnum = messageConfirmService.getConfirmStatus(message.getMsgId());

        // 获得应该有的确认
        if (topicLevel.getCode() == statusEnum.getCode()) {
            messageConfirmService.deleteConfirmStatus(message.getMsgId());
            return;
        }

        // 未确认，比较是否已经超过重试次数，没有的话进行重试
        if (currentRetryCount < maxRetryCount) {
            messageSender.retryOnConfirmTimeout(this);
        } else {
            messageConfirmService.deleteConfirmStatus(message.getMsgId());
            log.error("message confirm timeout and retry {} times still failed, message={}", currentRetryCount, JSONUtils.toJSONString(message));
        }
    }
}
