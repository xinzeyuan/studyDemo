/*
 * Copyright (c) 2019 OPPO. All rights reserved.
 */
package com.oppo.iot.smarthome.lc.util;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;

/**
 * <p>
 * Description:
 * </p>
 *
 * @author
 * @version 1.0
 * @Date 2019/3/23
 */
public class ThreadUtils {
    private static final Logger log = LoggerFactory.getLogger(ThreadUtils.class);

    /**
     * 主线程池
     * 数量：4~64
     * @author yidingouyang
     * @date 2018/3/19 17:24
     */
    private static ExecutorService mainPool = new ThreadPoolExecutor(
                            2, 64, 10L, TimeUnit.SECONDS,
                            new ArrayBlockingQueue<>(4096),
                            new ThreadFactoryBuilder().setNameFormat("pool-%d").build(),
                            new ThreadPoolExecutor.AbortPolicy());

    /**
     * 执行某个Runnable
     * @param runnable
     *
     * @author yidingouyang
     * @date 2018/3/19 17:25
     */
    public static void execute(Runnable runnable) {
        mainPool.execute(runnable);
    }

    /**
     * 有回调的线程
     * @param callable
     * @param <T>
     * @return
     *
     * @author yidingouyang
     * @date 2018/3/19 17:25
     */
    public static <T> Future<T> submit(Callable<T> callable) {
        return mainPool.submit(callable);
    }
}
