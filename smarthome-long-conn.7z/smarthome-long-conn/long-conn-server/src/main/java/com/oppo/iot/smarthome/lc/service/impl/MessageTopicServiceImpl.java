package com.oppo.iot.smarthome.lc.service.impl;

import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import com.oppo.iot.smarthome.lc.mapper.MessageTopicMapper;
import com.oppo.iot.smarthome.lc.model.MessageTopic;
import com.oppo.iot.smarthome.lc.model.MessageTopicExample;
import com.oppo.iot.smarthome.lc.service.MessageTopicService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 80279309
 */
@Slf4j
@Service
public class MessageTopicServiceImpl implements MessageTopicService {

    @Autowired
    private MessageTopicMapper messageTopicMapper;
    @Autowired
    private RedissonClient redissonClient;

    @Override
    public MessageTopic getByCode(String topic) {

        // 先查询缓存，如果没有则查询数据库
        String key = RedisKeys.getKey(RedisKeys.MESSAGE_TOPIC, "all");
        RBucket<List<MessageTopic>> bucket = redissonClient.getBucket(key);
        List<MessageTopic> messageTopicList = bucket.get();

        // 根据code获取其中一个返回
        if (CollectionUtils.isNotEmpty(messageTopicList)) {
            for (MessageTopic messageTopic : messageTopicList) {
                if (messageTopic.getCode().equals(topic)) {
                    return messageTopic;
                }
            }
        }

        //如果缓存没有则查询数据库
        MessageTopicExample example = new MessageTopicExample();
        MessageTopicExample.Criteria criteria = example.createCriteria();
        if (topic == null) {
            return null;
        }
        List<MessageTopic> messageTopics = messageTopicMapper.selectByExample(example);

        //更新缓存
        bucket.set(messageTopics);

        // 根据code获取其中一个返回
        for (MessageTopic messageTopic : messageTopics) {
            if (messageTopic.getCode().equals(topic)) {
                return messageTopic;
            }
        }
        //如果都没有则返回null
        return null;
    }
}
