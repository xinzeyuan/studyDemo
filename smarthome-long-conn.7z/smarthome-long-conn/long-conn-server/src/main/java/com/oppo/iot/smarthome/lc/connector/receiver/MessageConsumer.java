package com.oppo.iot.smarthome.lc.connector.receiver;

/**
 * @author 80279309
 */
public interface MessageConsumer {

    /**
     * 消息处理接口
     * @param topic
     * @param key
     * @param message
     */
    void onMessage(String topic, String key, String message, Object listener);
}
