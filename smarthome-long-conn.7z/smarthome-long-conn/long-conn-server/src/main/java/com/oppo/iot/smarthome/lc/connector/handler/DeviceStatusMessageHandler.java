package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.DeviceStatusInMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.DeviceStatusOutMessage;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author 80279309
 */
@Slf4j
@Component("deviceStatusMessageHandler")
public class DeviceStatusMessageHandler extends AbstractMessageHandler<DeviceStatusInMessage, DeviceStatusOutMessage> {


    @Override
    public boolean isMatch(String topic) {
        return MqTopic.DEVICE_STATUS_TOPIC.equals(topic);
    }

    @Override
    public DeviceStatusInMessage decode(String message) {
        if (message == null) {
            return null;
        }

        return JSONUtils.parseObject(message, DeviceStatusInMessage.class);
    }

    @Override
    public DeviceStatusOutMessage handle(DeviceStatusInMessage inMessage, String topic) {
        log.info("device status inBoundMessage={}", JSONUtils.toJSONString(inMessage));
        if (inMessage == null) {
            return null;
        }

        // 设置产品属性信息
        List<DeviceStatusOutMessage.DeviceStatusProperty> statusProperties = new ArrayList<>();
        Map<String, Object> properties = inMessage.getProperties();
        if (properties == null || properties.isEmpty()) {
            return null;
        }
        properties.entrySet().forEach(e->{
            DeviceStatusOutMessage.DeviceStatusProperty deviceStatusProperty = DeviceStatusOutMessage.DeviceStatusProperty.builder()
                    .property(e.getKey())
                    .value(e.getValue())
                    .build();
            statusProperties.add(deviceStatusProperty);
        });


        DeviceStatusOutMessage outMessage = new DeviceStatusOutMessage();
        outMessage.setDeviceId(inMessage.getDeviceId());
        outMessage.setDeviceProperties(statusProperties);
        outMessage.setSsoId(inMessage.getSsoId());
        outMessage.setMsgId(inMessage.getMsgId());

        return outMessage;
    }

}
