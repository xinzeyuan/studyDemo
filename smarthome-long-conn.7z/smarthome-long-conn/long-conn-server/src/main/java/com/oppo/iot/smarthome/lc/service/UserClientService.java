package com.oppo.iot.smarthome.lc.service;

import com.oppo.iot.smarthome.lc.model.UserClient;

import java.util.List;

/**
 * @author 80279309
 */
public interface UserClientService {

    /**
     * 新增
     * @param userClient 用户长连接信息
     * @return 长连接信息
     */
    UserClient add(UserClient userClient);

    /**
     * 删除
     * @param userClient 不位空的属性作为条件，用and连接
     * @return 删除条数
     */
    int remove(UserClient userClient);


    /**
     * 带缓存的查询, 按照ssoId为单位缓存
     * @param ssoId
     * @return
     */
    List<UserClient> listBySsoId(String ssoId);
}
