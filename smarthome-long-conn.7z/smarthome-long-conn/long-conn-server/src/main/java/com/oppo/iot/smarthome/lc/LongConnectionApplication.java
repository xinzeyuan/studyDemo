package com.oppo.iot.smarthome.lc;

import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.LegacyCookieProcessor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;

/**
 * @author 80279309
 */
@SpringBootApplication
@MapperScan("com.oppo.iot.smarthome.lc.mapper")
@Slf4j
public class LongConnectionApplication {

    public static void main(String[] args) {
        SpringApplication.run(LongConnectionApplication.class, args);
        log.info("===================LongConnectionApplication start success !!!===============");
    }

//    /**
//     * Tomcat Cookie 处理配置 Bean
//      */
//    @Bean
//    public WebServerFactoryCustomizer<TomcatServletWebServerFactory> cookieProcessorCustomizer() {
//        return (factory) -> factory.addContextCustomizers(
//                (context) -> context.setCookieProcessor(new LegacyCookieProcessor()));
//    }

}
