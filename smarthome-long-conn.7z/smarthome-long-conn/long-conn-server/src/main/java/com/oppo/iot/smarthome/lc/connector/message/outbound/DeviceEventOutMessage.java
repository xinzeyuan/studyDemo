package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 80279309
 *
 */
@Data
public class DeviceEventOutMessage extends OutBoundMessage {

    private String dialogInfoId;
    private String title;
    private String imageUrl;
    private String content;
    private int channelNameType;
    private int clickActionType;
    private String clickJumpUrl;
    private String clickJumpParameters;
    private int configNetworkType;
    private String manufactureCode;
    private List<JumpResult> jumpResults = new ArrayList<>();
    private int notificationId;
    private String notifyInfoId;

    @Data
    public static class JumpResult {
        private String deviceId;
        private String deviceName;
        private String controlPath;
        private int jumpType;
        private int position;
    }

}
