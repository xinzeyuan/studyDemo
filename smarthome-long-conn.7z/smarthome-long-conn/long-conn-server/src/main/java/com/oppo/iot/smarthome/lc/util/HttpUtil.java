package com.oppo.iot.smarthome.lc.util;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * @author huangcheng@oppo.com
 * @version v0.0.1
 * @date 2018/7/9
 */
public class HttpUtil {
    private static final Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    private static final CloseableHttpClient httpClient;

    private static CloseableHttpClient ignoreAuthClient;

    public static final String CHARSET = "UTF-8";

    private static RequestConfig config = null;

    public HttpUtil() {
    }

    public static CloseableHttpClient getTrustedSSLClient() throws Exception {
        SSLContext sslContext = (new SSLContextBuilder()).loadTrustMaterial((KeyStore) null, new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                return true;
            }
        }).build();
        SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        return HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
    }

    public static String doGet(String url, Map<String, String> params) {
        return doGet(url, params, CHARSET);
    }

    public static String doPost(String url, Map<String, String> params) {
        return doPost(url, params, CHARSET);
    }

    public static String doPut(String url, Map<String, String> params) {
        return doPut(url, params, CHARSET);
    }

    public static String doGet(String url, Map<String, String> params, String charset) {
        if (url != null && !"".equals(url)) {
            CloseableHttpResponse response = null;

            try {
                String result;
                if (params != null && !params.isEmpty()) {
                    List<NameValuePair> pairs = new ArrayList(params.size());
                    Iterator i$ = params.entrySet().iterator();

                    while (i$.hasNext()) {
                        Map.Entry<String, String> entry = (Map.Entry) i$.next();
                        result = (String) entry.getValue();
                        if (result != null) {
                            pairs.add(new BasicNameValuePair((String) entry.getKey(), result));
                        }
                    }

                    url = url + "?" + EntityUtils.toString(new UrlEncodedFormEntity(pairs, charset));
                }

                HttpGet httpGet = new HttpGet(url);
                response = httpClient.execute(httpGet);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode != 200) {
                    httpGet.abort();
                    throw new RuntimeException("HttpClient,error status code :" + statusCode);
                }

                HttpEntity entity = response.getEntity();
                result = null;
                if (entity != null) {
                    result = EntityUtils.toString(entity, "utf-8");
                }

                EntityUtils.consume(entity);
                String var8 = result;
                return var8;
            } catch (Exception var12) {
                var12.printStackTrace();
            } finally {
                IOUtils.closeQuietly(response);
            }

            return null;
        } else {
            return null;
        }
    }

    public static String doPost(String url, Map<String, String> params, String charset) {
        if (url != null && !"".equals(url)) {
            CloseableHttpResponse response = null;

            try {
                List<NameValuePair> pairs = null;
                if (params != null && !params.isEmpty()) {
                    pairs = new ArrayList(params.size());
                    Iterator i$ = params.entrySet().iterator();

                    while (i$.hasNext()) {
                        Map.Entry<String, String> entry = (Map.Entry) i$.next();
                        String value = (String) entry.getValue();
                        if (value != null) {
                            pairs.add(new BasicNameValuePair((String) entry.getKey(), value));
                        }
                    }
                }

                HttpPost httpPost = new HttpPost(url);
                if (pairs != null && pairs.size() > 0) {
                    httpPost.setEntity(new UrlEncodedFormEntity(pairs, "UTF-8"));
                }

                response = httpClient.execute(httpPost);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode != 200) {
                    httpPost.abort();
                    throw new RuntimeException("HttpClient,error status code :" + statusCode);
                }

                HttpEntity entity = response.getEntity();
                String result = null;
                if (entity != null) {
                    result = EntityUtils.toString(entity, "utf-8");
                }

                EntityUtils.consume(entity);
                String var9 = result;
                return var9;
            } catch (Exception var13) {
                var13.printStackTrace();
            } finally {
                IOUtils.closeQuietly(response);
            }

            return null;
        } else {
            return null;
        }
    }

    public static String doPut(String url, Map<String, String> params, String charset) {
        if (url != null && !"".equals(url)) {
            CloseableHttpResponse response = null;

            try {
                List<NameValuePair> pairs = null;
                if (params != null && !params.isEmpty()) {
                    pairs = new ArrayList(params.size());
                    pairs.add(new BasicNameValuePair("_method", "PUT"));
                    Iterator i$ = params.entrySet().iterator();

                    while (i$.hasNext()) {
                        Map.Entry<String, String> entry = (Map.Entry) i$.next();
                        String value = (String) entry.getValue();
                        if (value != null) {
                            pairs.add(new BasicNameValuePair((String) entry.getKey(), value));
                        }
                    }
                }

                HttpPost httpPut = new HttpPost(url);
                if (pairs != null && pairs.size() > 0) {
                    httpPut.setEntity(new UrlEncodedFormEntity(pairs, "UTF-8"));
                }

                httpPut.setHeader("Content-Type", "application/x-www-form-urlencoded");
                response = httpClient.execute(httpPut);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode != 200) {
                    httpPut.abort();
                    throw new RuntimeException("HttpClient,error status code :" + statusCode);
                }

                HttpEntity entity = response.getEntity();
                String result = null;
                if (entity != null) {
                    result = EntityUtils.toString(entity, "utf-8");
                }

                EntityUtils.consume(entity);
                String var9 = result;
                return var9;
            } catch (Exception var13) {
                var13.printStackTrace();
            } finally {
                IOUtils.closeQuietly(response);
            }

            return null;
        } else {
            return null;
        }
    }

    public static String getIpAddr(HttpServletRequest request) {
        String ipAddress = request.getHeader("x-forwarded-for");
        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }

        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }

        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (ipAddress.equals("127.0.0.1") || ipAddress.equals("0:0:0:0:0:0:0:1")) {
                InetAddress inet = null;

                try {
                    inet = InetAddress.getLocalHost();
                } catch (UnknownHostException var4) {
                    var4.printStackTrace();
                }

                ipAddress = inet.getHostAddress();
            }
        }

        if (ipAddress != null && ipAddress.length() > 15 && ipAddress.indexOf(",") > 0) {
            ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
        }

        return ipAddress;
    }

    public static String inputStreamToString(InputStream in, String encoding) throws Exception {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        boolean var4 = true;

        int count;
        while ((count = in.read(data, 0, 1024)) != -1) {
            outStream.write(data, 0, count);
        }

        in.close();
        return new String(outStream.toByteArray(), encoding);
    }

    public static String sendPost(String strUrl, String content, Map<String, String> headers) {
        return sendPost(strUrl, content, headers, "utf-8");
    }

    public static String sendPost(String strUrl, String content, Map<String, String> headers, String charset) {
        URL httpurl = null;
        HttpURLConnection httpConn = null;
        String returnStr = "";
        OutputStream outs = null;

        String var9;
        try {
            httpurl = new URL(strUrl);
            httpConn = (HttpURLConnection) httpurl.openConnection();
            httpConn.setConnectTimeout(10000);
            httpConn.setReadTimeout(10000);
            httpConn.setRequestMethod("POST");
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            httpConn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            if (headers != null) {
                Iterator iterator = headers.entrySet().iterator();

                while (iterator.hasNext()) {
                    Map.Entry<String, String> entry = (Map.Entry) iterator.next();
                    httpConn.setRequestProperty((String) entry.getKey(), (String) entry.getValue());
                }
            }

            outs = httpConn.getOutputStream();
            IOUtils.write(content, outs);
            byte[] responseBytes = IOUtils.toByteArray(httpConn.getInputStream());
            var9 = new String(responseBytes, charset);
            return var9;
        } catch (Exception var13) {
            logger.error("执行HTTP Post请求" + strUrl + "时，发生异常！", var13);
            var9 = returnStr;
        } finally {
            IOUtils.closeQuietly(outs);
            if (httpConn != null) {
                httpConn.disconnect();
            }

        }

        return var9;
    }


    public static String doIgnoreAuthPost(String url, Map<String, String> params, Map<String, String> header) {
        if (url != null && !"".equals(url)) {
            CloseableHttpResponse response = null;

            try {
                List<NameValuePair> pairs = null;
                if (params != null && !params.isEmpty()) {
                    pairs = new ArrayList(params.size());
                    Iterator i$ = params.entrySet().iterator();

                    while (i$.hasNext()) {
                        Map.Entry<String, String> entry = (Map.Entry) i$.next();
                        String value = (String) entry.getValue();
                        if (value != null) {
                            pairs.add(new BasicNameValuePair((String) entry.getKey(), value));
                        }
                    }
                }

                HttpPost httpPost = new HttpPost(url);
                if (pairs != null && pairs.size() > 0) {
                    httpPost.setEntity(new UrlEncodedFormEntity(pairs, CHARSET));
                }

                if (!CollectionUtils.isEmpty(header)) {
                    for (Map.Entry entry : header.entrySet()) {
                        httpPost.setHeader(entry.getKey().toString(), entry.getValue().toString());
                    }
                }

                logger.debug("----------doIgnoreAuthPost ready to execute url:{}-----", url);
                response = ignoreAuthClient.execute(httpPost);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode != 200) {
                    httpPost.abort();
                    throw new RuntimeException("HttpClient,error status code :" + statusCode);
                }

                HttpEntity entity = response.getEntity();
                String result = null;
                if (entity != null) {
                    result = EntityUtils.toString(entity, CHARSET);
                }

                EntityUtils.consume(entity);
                String var9 = result;
                return var9;
            } catch (Exception var13) {
                logger.error(null, var13);
            } finally {
                IOUtils.closeQuietly(response);
            }

            return null;
        } else {
            return null;
        }
    }

    public static String formatUrlMap(Map<String, String> paraMap, boolean urlEncode, boolean keyToLower) {
        String buff;
        Map tmpMap = paraMap;

        try {
            List<Map.Entry<String, String>> infoIds = new ArrayList(tmpMap.entrySet());
            Collections.sort(infoIds, new Comparator<Map.Entry<String, String>>() {
                @Override
                public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
                    return ((String) o1.getKey()).toString().compareTo((String) o2.getKey());
                }
            });
            StringBuilder buf = new StringBuilder();
            Iterator i$ = infoIds.iterator();

            while (i$.hasNext()) {
                Map.Entry<String, String> item = (Map.Entry) i$.next();
                if (item.getKey() != null && !"".equals(item.getKey())) {
                    String key = (String) item.getKey();
                    String val = (String) item.getValue();
                    if (urlEncode) {
                        val = URLEncoder.encode(val, "utf-8");
                    }

                    if (keyToLower) {
                        buf.append(key.toLowerCase() + "=" + val);
                    } else {
                        buf.append(key + "=" + val);
                    }

                    buf.append("&");
                }
            }

            buff = buf.toString();
            if (!buff.isEmpty()) {
                buff = buff.substring(0, buff.length() - 1);
            }

            return buff;
        } catch (Exception var11) {
            return null;
        }
    }

    static {
        config = RequestConfig.custom().setConnectTimeout(10000).setSocketTimeout(10000).build();
        httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

        try {
            ignoreAuthClient = getTrustedSSLClient();
        } catch (Exception var1) {
            logger.error((String) null, var1);
        }

    }
}
