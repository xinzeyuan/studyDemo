package com.oppo.iot.smarthome.lc.enums;

/**
 * @author 80279309
 */
public enum TopicLevelEnum {
    // 不需要确认
    NO_RESPONSE(1, "不需要确认"),

    // 需要中间的确认
    MIDDLE_WARE_RESPONSE(2, "需要中间的确认"),

    // 需要客户端的确认
    CLIENT_RESPONSE(3, "需要客户端的确认"),
    ;

    private int code;
    private String remark;

    TopicLevelEnum(int code, String remark) {
        this.code = code;
        this.remark = remark;
    }

    public static TopicLevelEnum getByCode(int code) {
        if (code <= 0) {
            return null;
        }

        for (TopicLevelEnum e : TopicLevelEnum.values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return null;
    }

    public int getCode() {
        return code;
    }

    public String getRemark() {
        return remark;
    }
}
