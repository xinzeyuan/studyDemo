package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.DeviceBindInMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.DeviceBindOutMessage;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

/**
 * 配网处理器
 * @author 80279309
 */
@Slf4j
@Component
public class DeviceBindMessageHandler extends AbstractMessageHandler<DeviceBindInMessage, DeviceBindOutMessage> {


    @Override
    public boolean isMatch(String topic) {
        return MqTopic.DEVICE_BIND_TOPIC.equals(topic);
    }

    @Override
    public DeviceBindInMessage decode(String message) {
        if (StringUtils.isBlank(message)) {
            return null;
        }
        return JSONUtils.parseObject(message, DeviceBindInMessage.class);
    }

    @Override
    public DeviceBindOutMessage handle(DeviceBindInMessage inMessage, String topic) {
        if (inMessage == null) {
            return null;
        }
        DeviceBindOutMessage outMessage = new DeviceBindOutMessage();
        BeanUtils.copyProperties(inMessage, outMessage);
        return outMessage;
    }


}
