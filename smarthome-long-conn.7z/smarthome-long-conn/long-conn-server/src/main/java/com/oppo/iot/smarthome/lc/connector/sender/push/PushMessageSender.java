package com.oppo.iot.smarthome.lc.connector.sender.push;

import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;
import com.oppo.iot.smarthome.lc.connector.sender.AbstractMessageSender;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author 80279309
 */
@Service
@Slf4j
public class PushMessageSender extends AbstractMessageSender {

    @Override
    public boolean doSend(CommonOutboundMessage message, String clientId) {

        // todo-yh: 发送动作本身，对接push团队
        log.info("=======send message use push, clientId={}, message={}", clientId, JSONUtils.toJSONString(message));
        return true;
    }
}
