package com.oppo.iot.smarthome.lc.enums;

/**
 * 消息确认状态
 * @author 80279309
 */
public enum MessageConfirmStatusEnum {

    // 不需要确认
    NO_CONFIRMED(1, "为收到确认"),

    // 收到中间的确认
    MIDDLE_WARE_CONFIRMED(2, "收到中间的确认"),

    // 收到客户端的确认
    CLIENT_CONFIRMED(3, "收到客户端的确认"),
    ;

    private int code;
    private String remark;

    MessageConfirmStatusEnum(int code, String remark) {
        this.code = code;
        this.remark = remark;
    }

    public static MessageConfirmStatusEnum getByCode(int code) {
        if (code <= 0) {
            return null;
        }
        for (MessageConfirmStatusEnum e : MessageConfirmStatusEnum.values()) {
            if (code == e.code) {
                return e;
            }
        }
        return null;
    }

    public int getCode() {
        return code;
    }

    public String getRemark() {
        return remark;
    }
}
