package com.oppo.iot.smarthome.lc.config;

import com.oppo.basic.heracles.client.core.spring.annotation.HeraclesDynamicConfig;
import lombok.Data;
import org.springframework.context.annotation.Configuration;

/**
 * 配置中心的获取的变量
 * @author 80279309
 */
@Configuration
@Data
public class ConfigCenter {

    @HeraclesDynamicConfig(fileName="application.properties" , key="send.confirm.timeout" , defaultValue = "6000")
    private long sendConfirmTimeout = 10000;

    @HeraclesDynamicConfig(fileName="application.properties" , key="send.max.retry" , defaultValue = "1")
    private int sendMaxRetry = 1;

    @HeraclesDynamicConfig(fileName="application.properties" , key="consume.max.retry" , defaultValue = "1")
    private int consumeMaxRetry = 1;
}
