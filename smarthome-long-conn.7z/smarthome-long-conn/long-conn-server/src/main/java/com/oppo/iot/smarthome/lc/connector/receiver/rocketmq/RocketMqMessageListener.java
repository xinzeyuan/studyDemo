package com.oppo.iot.smarthome.lc.connector.receiver.rocketmq;

import com.oppo.iot.smarthome.lc.connector.receiver.MessageConsumer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.CharSet;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * @author 80279309
 */
@Slf4j
@Component
public class RocketMqMessageListener implements MessageListenerConcurrently {

    @Autowired
    private MessageConsumer consumer;

    @Override
    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {

        /*
         * 解析成 topic key value后交给处理器
         */
        for (MessageExt msg : msgs) {
            try {
                String key = msg.getKeys();
                String topic = msg.getTopic();
                String value = new String(msg.getBody(), "UTF-8");
                log.info("rocketMQ receive message:{}", value);
                consumer.onMessage(topic, key, value, this);
            } catch (Exception e) {
                log.error("rocket MQ consumer error", e);
            }
        }
        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
    }
}
