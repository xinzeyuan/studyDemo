package com.oppo.iot.smarthome.lc.mapper;

import com.oppo.iot.smarthome.lc.model.UserClient;
import com.oppo.iot.smarthome.lc.model.UserClientExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserClientMapper {
    int countByExample(UserClientExample example);

    int deleteByExample(UserClientExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserClient record);

    int insertSelective(UserClient record);

    List<UserClient> selectByExample(UserClientExample example);

    UserClient selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserClient record, @Param("example") UserClientExample example);

    int updateByExample(@Param("record") UserClient record, @Param("example") UserClientExample example);

    int updateByPrimaryKeySelective(UserClient record);

    int updateByPrimaryKey(UserClient record);
}