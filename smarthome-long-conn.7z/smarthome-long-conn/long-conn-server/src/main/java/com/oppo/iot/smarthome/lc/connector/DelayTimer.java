package com.oppo.iot.smarthome.lc.connector;

import io.netty.util.HashedWheelTimer;
import io.netty.util.Timer;
import io.netty.util.TimerTask;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * 延迟队列timer
 * @author 80279309
 */
public class DelayTimer {

    private static class TimerHolder {
        private static final Timer timer = new HashedWheelTimer(Executors.defaultThreadFactory(), 1, TimeUnit.SECONDS, 512);
    }

    /**
     * 添加延迟任务
     * @param task 任务
     * @param timeout 延迟时间，单位毫秒
     */
    public static void addTask(TimerTask task, long timeout) {
        TimerHolder.timer.newTimeout(task, timeout, TimeUnit.MILLISECONDS);
    }
}
