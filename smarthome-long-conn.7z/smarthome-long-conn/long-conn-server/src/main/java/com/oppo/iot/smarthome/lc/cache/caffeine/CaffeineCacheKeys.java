package com.oppo.iot.smarthome.lc.cache.caffeine;

public enum CaffeineCacheKeys {

    /**
     * 发送重试次数 prefix+msgId
     */
    SEND_RETRY_PREFIX("iot:long_conn:consume_retry:");

    private String prefix;

    CaffeineCacheKeys(String prefix) {
        this.prefix = prefix;
    }

    public String getKey(String unique) {
        return this.prefix + unique;
    }
}
