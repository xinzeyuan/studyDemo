package com.oppo.iot.smarthome.lc.service;

import com.oppo.iot.smarthome.lc.enums.MessageConfirmStatusEnum;

/**
 * @author 80279309
 *
 */
public interface MessageConfirmService {

    int CONSUME = 1;
    int SEND = 2;

    /**
     * todo-yh: 保存待确认消息的状态, 中间件返回结果后调用
     * @param msgId
     * @param statusEnum
     */
    void saveConfirmStatus(String msgId, MessageConfirmStatusEnum statusEnum);

    /**
     * 删除待确认消息的状态
     * @param msgId
     */
    void deleteConfirmStatus(String msgId);

    /**
     * 查询待确认消息的状态
     * @param msgId
     * @return
     */
    MessageConfirmStatusEnum getConfirmStatus(String msgId);

    /**
     * 查询消息重试次数
     * @param msgId 消息id
     * @param consumeOrSend 1 消费，2发送
     * @return 次数
     */
    int getMessageRetryCount(String msgId, int consumeOrSend);

    /**
     * 设置消息重试次数
     * @param msgId
     * @param count
     * @param consumeOrSend
     * @return
     */
    void setMessageRetryCount(String msgId, int count, int consumeOrSend);

    /**
     * 删除消息重试次数
     * @param msgId
     * @param consumeOrSend
     */
    void deleteMessageRetryCount(String msgId, int consumeOrSend);
}
