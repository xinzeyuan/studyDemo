package com.oppo.iot.smarthome.lc.connector.sender;

import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;

/**
 * 向长连接中间件发送数据
 * @author 80279309
 */
public interface MessageSender {

    /**
     * 发送数据
     *
     * @param message 消息内容
     * @param clientId 消息接收者
     * @return 发送成功返回true
     */
    boolean send(CommonOutboundMessage message, String clientId);


    /**
     * 超时确认重试
     * @param task
     * @return
     */
    boolean retryOnConfirmTimeout(SendConfirmTimeoutTask task);

}
