package com.oppo.iot.smarthome.lc.cache.caffeine;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.util.concurrent.TimeUnit;

/**
 * 本地缓存
 * @author 80279309
 */
public class CaffeineCacheUtil {

    public static Cache<String, Integer> sendRetryCount = Caffeine.newBuilder()
            .maximumSize(10_000)
            .expireAfterWrite(3, TimeUnit.MINUTES)
            .build();

}
