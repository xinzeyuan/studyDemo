package com.oppo.iot.smarthome.lc.connector.health;

import com.oppo.iot.smarthome.lc.connector.DelayTimer;
import com.oppo.iot.smarthome.lc.model.UserClient;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import com.oppo.iot.smarthome.lc.service.UserClientService;
import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import lombok.extern.slf4j.Slf4j;

/**
 * 心跳任务
 * @author 80279309
 */
@Slf4j
public class HeartBeatTask implements TimerTask {

    private String ssoId;
    private String clientId;
    private HealthHandler healthHandler;
    private UserClientService userClientService;
    private MessageTopicSubscribeService subscribeService;

    public HeartBeatTask(String ssoId, String clientId, HealthHandler healthHandler, UserClientService userClientService, MessageTopicSubscribeService subscribeService) {
        this.ssoId = ssoId;
        this.clientId = clientId;
        this.healthHandler = healthHandler;
        this.userClientService = userClientService;
        this.subscribeService = subscribeService;
    }

    @Override
    public void run(Timeout timeout) throws Exception {
        Long time = healthHandler.getLastBeatTime(clientId);
        if (time == null || time <= 0) {
            // 没有持续心跳，说明已经掉线，删除client信息，剔除订阅关系
            log.info("client app offline , ssoId={}, clientId={}", ssoId, clientId);
            UserClient cond = new UserClient();
            cond.setClientId(clientId);
            userClientService.remove(cond);

            subscribeService.unsubscribe(ssoId, clientId);
            log.info("client app offline, clean success , ssoId={}, clientId={}", ssoId, clientId);

        } else {
            // 有持续心跳，重新倒计时
            DelayTimer.addTask(this, HealthHandler.HEARTBEAT_TIMEOUT);
        }
    }
}
