package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

import java.util.Date;

/**
 * 配网结果（设备绑定）消息
 * @author 80279309
 */
@Data
public class DeviceBindInMessage extends InboundMessage {

    private String bindKey;
    private String deviceId;
    private long homeAddr;
    /**
     * 成功失败标志
     */
    private int result;
    private Date bindTime;
}
