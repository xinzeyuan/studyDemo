package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.UserEventInMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.UserEventOutMessage;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * @author 80279309
 * 用户事件消息处理
 */
@Slf4j
@Component
public class UserEventMessageHandler extends AbstractMessageHandler<UserEventInMessage, UserEventOutMessage> {

    @Override
    public boolean isMatch(String topic) {
        return MqTopic.USER_SHARE_DEVICE_TOPIC.equals(topic) ||
                MqTopic.USER_FAMILY_INVITE_TOPIC.equals(topic) ||
                MqTopic.USER_FAMILY_MEMBER_INVITE_TOPIC.equals(topic);
    }

    @Override
    public UserEventInMessage decode(String message) {

        UserEventInMessage inMessage = JSONUtils.parseObject(message, UserEventInMessage.class);
        inMessage.setMsg(JSONUtils.parseObject(message, HashMap.class));
        return inMessage;
    }

    @Override
    public UserEventOutMessage handle(UserEventInMessage inMessage, String topic) {

        UserEventOutMessage outMessage = new UserEventOutMessage();
        outMessage.setSsoId(inMessage.getSsoId());
        outMessage.setMsg(inMessage.getMsg());
        outMessage.setMsgId(inMessage.getMsgId());
        return outMessage;
    }
}
