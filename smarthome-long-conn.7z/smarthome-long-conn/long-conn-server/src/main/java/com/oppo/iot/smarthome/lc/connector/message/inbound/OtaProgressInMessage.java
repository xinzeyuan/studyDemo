package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

/**
 * OTA进度消息
 * @author 80279309
 */
@Data
public class OtaProgressInMessage extends InboundMessage {

    private String deviceId;
    private String target;
    private String status;
    private int percent;
    private String version;
}
