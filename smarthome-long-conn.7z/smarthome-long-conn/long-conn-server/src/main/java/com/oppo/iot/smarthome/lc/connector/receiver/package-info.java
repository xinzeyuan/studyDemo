package com.oppo.iot.smarthome.lc.connector.receiver;

// 接收来自业务系统的消息