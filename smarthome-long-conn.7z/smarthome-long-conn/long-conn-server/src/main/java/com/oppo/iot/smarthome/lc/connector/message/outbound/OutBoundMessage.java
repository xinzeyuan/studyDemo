package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Data;

/**
 * @author 80279309
 */
@Data
public class OutBoundMessage implements java.io.Serializable {
    private String msgId;
    private String ssoId;
}
