package com.oppo.iot.smarthome.lc.connector.message;

/**
 *
 * mq的topic
 * @author 80279309
 */
public class MqTopic {

    /** 设备状态变更 */
    public static final String DEVICE_STATUS_TOPIC = "test-fun";

    /** 设备事件变更 */
    public static final String DEVICE_EVENT_TOPIC = "test-fun2";

    /** 设备配网成功 */
    public static final String DEVICE_BIND_TOPIC = "test-fun3";

    /** 设备OTA进度 */
    public static final String OTA_PROGRESS_TOPIC = "test-fun4";

    /** 用户分享设备 */
    public static final String USER_SHARE_DEVICE_TOPIC = "test-fun5";
    /** 用户被家人邀请 */
    public static final String USER_FAMILY_INVITE_TOPIC = "test-fun6";
    /** 用户被剔除家庭 */
    public static final String USER_FAMILY_MEMBER_INVITE_TOPIC = "test-fun7";
}
