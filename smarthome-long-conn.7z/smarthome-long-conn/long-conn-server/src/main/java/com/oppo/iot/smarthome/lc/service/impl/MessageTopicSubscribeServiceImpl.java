package com.oppo.iot.smarthome.lc.service.impl;

import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * @author 80279309
 */
@Slf4j
@Service
public class MessageTopicSubscribeServiceImpl implements MessageTopicSubscribeService {

    @Autowired
    private RedissonClient redissonClient;

    @Override
    public boolean subscribe(String ssoid, String clientId, List<String> topic) {
        log.info("subscribe param: ssoid = {}, clientId = {}, topic = {}", ssoid, clientId, topic);
        if (StringUtils.isBlank(ssoid) || StringUtils.isBlank(clientId) || CollectionUtils.isEmpty(topic)) {
            return false;
        }
        String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_ID_TOPIC_PREFIX, ssoid);
        RMap<String, List<String>> map = redissonClient.getMap(key);
        map.put(clientId, topic);
        return true;
    }

    @Override
    public boolean unsubscribe(String ssoid, String clientId, List<String> topic) {
        log.info("unsubscribe param: ssoid = {}, clientId = {}, top = {}", ssoid, clientId, topic);

        if (StringUtils.isBlank(ssoid) || StringUtils.isBlank(clientId)) {
            return false;
        }
        if (CollectionUtils.isEmpty(topic)) {
            return true;
        }

        try {
            String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_ID_TOPIC_PREFIX, ssoid);
            RMap<String, List<String>> map = redissonClient.getMap(key);

            List<String> topics = map.get(clientId);
            topics.removeAll(topic);
            map.put(clientId, topics);
            return true;
        } catch (Exception e) {
            return false;
        }

    }


    @Override
    public boolean unsubscribe(String ssoid, String clientId) {
        log.info("unsubscribe param: ssoid = {}, clientId = {}", ssoid, clientId);

        if (StringUtils.isBlank(ssoid) || StringUtils.isBlank(clientId)) {
            return false;
        }
        try{
            String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_ID_TOPIC_PREFIX, ssoid);
            RMap<String, List<String>> map = redissonClient.getMap(key);
            map.remove(clientId);
            return true;
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public List<MessageTopicSubscribeBo> userTopic(String ssoid) {
        log.info("user topic param: ssoid = {}", ssoid);
        if (StringUtils.isBlank(ssoid)) {
            return new ArrayList<>();
        }
        String key = RedisKeys.getKey(RedisKeys.USER_CLIENT_ID_TOPIC_PREFIX, ssoid);
        RMap<String, List<String>> map = redissonClient.getMap(key);
        if (MapUtils.isEmpty(map)) {
            return new ArrayList<>();
        }

        List<MessageTopicSubscribeBo> messageTopicSubscribeBoList = new ArrayList<>();
        map.entrySet().stream().forEach(e -> {
                    String clientId = e.getKey();
                    List<String> topicList = e.getValue();
                    MessageTopicSubscribeBo messageTopicSubscribeBo = new MessageTopicSubscribeBo();
                    messageTopicSubscribeBo.setSsoid(ssoid);
                    messageTopicSubscribeBo.setClientId(clientId);
                    messageTopicSubscribeBo.setTopic(topicList);
                    messageTopicSubscribeBoList.add(messageTopicSubscribeBo);
                }
        );
        return messageTopicSubscribeBoList;
    }
}
