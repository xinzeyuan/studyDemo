package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

/**
 * 用户触发消息,
 * @author 80279309
 */
@Data
public class UserEventInMessage extends InboundMessage {

    private String ssoId;

    /**
     * 基本透传
      */
    private Object msg;
}
