package com.oppo.iot.smarthome.lc.facade.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.oppo.iot.smarthome.lc.connector.DelayTimer;
import com.oppo.iot.smarthome.lc.connector.health.HealthHandler;
import com.oppo.iot.smarthome.lc.connector.health.HeartBeatTask;
import com.oppo.iot.smarthome.lc.facade.api.ConnectionManageFacade;
import com.oppo.iot.smarthome.lc.facade.bo.UserClientBo;
import com.oppo.iot.smarthome.lc.model.UserClient;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import com.oppo.iot.smarthome.lc.service.UserClientService;
import io.netty.util.TimerTask;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author 80279309
 */
@Slf4j
@Service
public class ConnectionManageFacadeImpl implements ConnectionManageFacade {

    @Autowired
    private UserClientService userClientService;
    @Autowired
    private HealthHandler healthHandler;
    @Autowired
    private MessageTopicSubscribeService messageTopicSubscribeService;

    @Override
    public Boolean registerConn(UserClientBo userClientBo) {
        log.info("register connection params={}", userClientBo);

        // 参数校验
        boolean isInvalidParams = userClientBo == null
                || StringUtils.isBlank(userClientBo.getSsoid())
                || StringUtils.isBlank(userClientBo.getClientId())
                || StringUtils.isBlank(userClientBo.getAppVersion());
        if (isInvalidParams) {
            return false;
        }
        // 处理连接信息，判断，如果存在则删除，重新添加，不存在则直接添加
        UserClient condition = new UserClient();
        condition.setClientId(userClientBo.getClientId());
        userClientService.remove(condition);

        UserClient uc = userClientService.add(convert(userClientBo));

        // 添加第一次心跳，增加心跳超时检测的任务
        healthHandler.setLastBeatTime(userClientBo.getClientId());
        TimerTask heartBeatTask = new HeartBeatTask(userClientBo.getSsoid(), userClientBo.getClientId(),
                healthHandler, userClientService, messageTopicSubscribeService);
        DelayTimer.addTask(heartBeatTask, HealthHandler.HEARTBEAT_TIMEOUT);
        return uc != null;
    }

    @Override
    public Boolean cancelConn(UserClientBo userClientBo) {
        log.info("cancel connection params={}", userClientBo);

        // 参数校验
        boolean isInvalidParams = userClientBo == null
                || StringUtils.isBlank(userClientBo.getClientId());
        if (isInvalidParams) {
            return false;
        }

        // 注册信息
        int row = userClientService.remove(convert(userClientBo));
        return row > 0;
    }

    @Override
    public Boolean isChannelHealth(String ssoId, String clientId) {
        // 更新最新的心跳时间
        healthHandler.setLastBeatTime(clientId);

        // 查询和push心跳异常时候记录的push服务状态值，根据值返回通道情况
        return healthHandler.isChannelHealth();
    }


    private UserClient convert(UserClientBo bo) {
        if (bo == null) {
            return null;
        }
        UserClient uc = new UserClient();
        BeanUtils.copyProperties(bo, uc);
        return uc;
    }

    private UserClientBo convert(UserClient uc) {
        if (uc == null) {
            return null;
        }
        UserClientBo bo = new UserClientBo();
        BeanUtils.copyProperties(uc, bo);
        return bo;
    }

}
