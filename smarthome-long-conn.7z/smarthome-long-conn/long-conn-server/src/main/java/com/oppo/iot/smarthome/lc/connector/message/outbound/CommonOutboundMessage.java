package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Builder;
import lombok.Data;

/**
 * @author 80279309
 */
@Data
@Builder
public class CommonOutboundMessage implements java.io.Serializable {

    private String msgId;
    private String topic;
    private String key;
    private long ts;
    private Object msg;
}
