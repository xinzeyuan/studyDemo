package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Data;

@Data
public class UserEventOutMessage extends OutBoundMessage {

    private String ssoId;
    /**
     * 基本透传，所以用object
     */
    private Object msg;
}
