package com.oppo.iot.smarthome.lc.connector.sender;

// 給长连接中间件交互  收发消息