package com.oppo.iot.smarthome.lc.connector;

// 消息转发的核心模块

/*
|---sender 发送消息给长连接中间件
 ---receiver 接受业务系统的消息




 */