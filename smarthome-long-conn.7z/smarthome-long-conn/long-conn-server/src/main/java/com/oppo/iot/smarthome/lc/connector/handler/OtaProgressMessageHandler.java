package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.connector.message.inbound.OtaProgressInMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.OtaProgressOutMessage;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

/**
 * @author 80279309
 *
 */
@Slf4j
@Component
public class OtaProgressMessageHandler extends AbstractMessageHandler<OtaProgressInMessage, OtaProgressOutMessage>{

    @Override
    public boolean isMatch(String topic) {
        return MqTopic.OTA_PROGRESS_TOPIC.equals(topic);
    }

    @Override
    public OtaProgressInMessage decode(String message) {
        return JSONUtils.parseObject(message, OtaProgressInMessage.class);
    }

    @Override
    public OtaProgressOutMessage handle(OtaProgressInMessage inMessage, String topic) {
        if (inMessage == null) {
            return null;
        }
        OtaProgressOutMessage outMessage = new OtaProgressOutMessage();
        BeanUtils.copyProperties(inMessage, outMessage);
        return outMessage;
    }

}
