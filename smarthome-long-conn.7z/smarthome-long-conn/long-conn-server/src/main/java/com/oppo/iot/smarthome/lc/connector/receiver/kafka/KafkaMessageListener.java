package com.oppo.iot.smarthome.lc.connector.receiver.kafka;

import com.oppo.iot.smarthome.lc.connector.receiver.MessageConsumer;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * @author 80279309
 */
@Slf4j
@Service
public class KafkaMessageListener {

    @Autowired
    private MessageConsumer consumer;

    @KafkaListener(topics = {MqTopic.DEVICE_STATUS_TOPIC/*,
                                MqTopic.DEVICE_EVENT_TOPIC,
                                MqTopic.DEVICE_BIND_TOPIC,
                                MqTopic.OTA_PROGRESS_TOPIC,
                                MqTopic.USER_SHARE_DEVICE_TOPIC,
                                MqTopic.USER_FAMILY_INVITE_TOPIC,
                                MqTopic.USER_FAMILY_MEMBER_INVITE_TOPIC,*/
    })
    public void listen(ConsumerRecord<String, String> data) {
        /*
         * 解析成 topic key value后交给处理器
         */
        String key = data.key();
        String topic = data.topic();
        String value = data.value();
        log.info("kafka receive message:{}", value);
        consumer.onMessage(topic, key, value, this);
    }
}
