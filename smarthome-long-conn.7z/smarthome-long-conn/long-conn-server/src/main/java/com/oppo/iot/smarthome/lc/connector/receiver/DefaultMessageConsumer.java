package com.oppo.iot.smarthome.lc.connector.receiver;

import com.oppo.iot.smarthome.lc.connector.handler.MessageHandler;
import com.oppo.iot.smarthome.lc.connector.message.inbound.InboundMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.OutBoundMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 消息消费处理器
 * @author 80279309
 */
@Slf4j
@Component
public class DefaultMessageConsumer implements MessageConsumer {

    @Autowired
    private List<MessageHandler> messageHandlerList;

    @Override
    public void onMessage(String topic, String key, String message, Object listener) {
        log.info("on message topic={}, key={}, value={}", topic, key, message);
        if (StringUtils.isBlank(message)) {
            return;
        }

        messageHandlerList.stream().filter(e->e.isMatch(topic)).forEach(e-> {

            OutBoundMessage outBoundMessage = null;
            try {
                // 转换接收的消息为业务对象
                InboundMessage inboundMessage = e.decode(message);

                // 处理业务对象，转换为待发送对象
                outBoundMessage = e.handle(inboundMessage, topic);

            } catch (Exception ex) {
                //  消费失败的处理
                e.onInboundException(message, topic, key, listener, ex);
            }

            // 不为空代表需要发送
            if (outBoundMessage != null) {
                try {
                    e.send(outBoundMessage, topic, key);
                } catch (Exception ex) {
                    // 发送异常处理
                    e.onOutboundException(outBoundMessage, topic, key, ex);
                }
            }
        });
    }
}
