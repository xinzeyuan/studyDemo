package com.oppo.iot.smarthome.lc.cache.redis;

import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author 80279309
 */
@Component
public class RedisUtil {

    @Autowired
    private RedissonClient redissonClient;

    // 封装几个常用的方法
}
