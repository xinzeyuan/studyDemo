package com.oppo.iot.smarthome.lc.connector.handler;

import com.oppo.iot.smarthome.lc.config.ConfigCenter;
import com.oppo.iot.smarthome.lc.connector.message.inbound.InboundMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.CommonOutboundMessage;
import com.oppo.iot.smarthome.lc.connector.message.outbound.OutBoundMessage;
import com.oppo.iot.smarthome.lc.connector.receiver.kafka.KafkaMessageListener;
import com.oppo.iot.smarthome.lc.connector.receiver.rocketmq.RocketMqMessageListener;
import com.oppo.iot.smarthome.lc.connector.sender.MessageSender;
import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;
import com.oppo.iot.smarthome.lc.service.MessageConfirmService;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import com.oppo.iot.smarthome.lc.service.UserClientService;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author 80279309
 */
@Slf4j
public abstract class AbstractMessageHandler<IN extends InboundMessage, OUT extends OutBoundMessage> implements MessageHandler<IN, OUT> {

    @Autowired
    protected MessageTopicSubscribeService topicSubscribeService;

    @Autowired
    protected UserClientService userClientService;

    @Autowired
    protected MessageConfirmService messageConfirmService;

    @Autowired
    protected MessageSender sender;

    @Autowired
    protected KafkaTemplate kafkaTemplate;

    @Autowired
    protected DefaultMQProducer producer;

    @Autowired
    private ConfigCenter configCenter;


    @Override
    public void send(OUT outMessage, String topic, String key) {
        String ssoId = outMessage.getSsoId();
        log.info("send, topic={}, ssoId={}", topic, ssoId);
        List<String> clientList = getTargetClient(ssoId, topic);
        log.info("send, topic={}, ssoId={}, clients={}", topic, ssoId, JSONUtils.toJSONString(clientList));
        if (CollectionUtils.isEmpty(clientList)) {
            return;
        }

        // convert message
        CommonOutboundMessage out = CommonOutboundMessage.builder()
                .msgId(outMessage.getMsgId())
                .topic(topic)
                .key(key)
                .ts(System.currentTimeMillis())
                .msg(outMessage)
                .build();
        // send
        clientList.forEach(e -> sender.send(out, e));
    }

    @Override
    public void onInboundException(String message, String topic, String key, Object listener, Exception e) {

        InboundMessage in = JSONUtils.parseObject(message, InboundMessage.class);
        String msgId = in.getMsgId();

        // 消费失败重试，放回队列重新消息，超出重试次数退出
        int count = messageConfirmService.getMessageRetryCount(msgId, MessageConfirmService.CONSUME);
        if (count > configCenter.getConsumeMaxRetry()) {
            log.error("message consume failed, retry {} times, topic={}, key={},message={}", count, topic, key, message);
            messageConfirmService.deleteMessageRetryCount(msgId, MessageConfirmService.CONSUME);
            return;
        }

        if (listener instanceof KafkaMessageListener) {
            kafkaTemplate.send(topic, key, message).addCallback(new ListenableFutureCallback() {
                @Override
                public void onFailure(Throwable ex) {
                    log.error("kafka retry failed, topic=" + topic + ", key=" + key + ",message=" + message + ", error=", e);
                }

                @Override
                public void onSuccess(Object result) {
                    messageConfirmService.setMessageRetryCount(msgId, count + 1, MessageConfirmService.CONSUME);
                }
            });
            return;
        }

        if (listener instanceof RocketMqMessageListener) {
            try {
                Message msg = new Message();
                msg.setTopic(topic);
                msg.setBody(message.getBytes("UTF-8"));
                producer.send(msg, new SendCallback() {
                    @Override
                    public void onSuccess(SendResult sendResult) {
                        messageConfirmService.setMessageRetryCount(msgId, count + 1, MessageConfirmService.CONSUME);
                    }

                    @Override
                    public void onException(Throwable e) {
                        log.error("rocketmq retry failed, topic=" + topic + ", key=" + key + ",message=" + message + ", error=", e);
                    }
                });
            } catch (Exception ex) {
                log.error("rocketmq retry error, topic=" + topic + ", key=" + key + ",message=" + message + ", error=", ex);
            }
            return;
        }
        log.error("consume message error: topic=" + topic + ", key=" + key + ", value=" + message);
    }

    @Override
    public void onOutboundException(OUT message, String topic, String key, Exception e) {


        String msgId = message.getMsgId();

        // 发送失败，进行重试，超出次数退出。

        int count = messageConfirmService.getMessageRetryCount(msgId, MessageConfirmService.SEND);
        if (count > configCenter.getConsumeMaxRetry()) {
            log.error("message consume failed, retry {} times, topic={}, key={},message={}", count, topic, key, message);
            messageConfirmService.deleteMessageRetryCount(msgId, MessageConfirmService.SEND);
            return;
        }

        try {
            this.send(message, topic, key);
            messageConfirmService.setMessageRetryCount(msgId, count + 1, MessageConfirmService.SEND);
        } catch (Exception ex) {
            log.error("send message retry error: topic=" + topic + ", key=" + key + ", value=" + message, ex);
        }
        log.error("send message error: topic=" + topic + ", key=" + key + ", value=" + message);
    }


    /**
     * 获取需要发送消息的客户端
     *
     * @param ssoId 用户id
     * @param topic 消息主题
     * @return 客户端列表
     */
    protected List<String> getTargetClient(String ssoId, String topic) {

        // 根据ssoid 获取用的订阅关系，并找到clientId
        List<MessageTopicSubscribeBo> list = topicSubscribeService.userTopic(ssoId);
        if (CollectionUtils.isEmpty(list)) {
            log.info("device status message handler, ssoid={} not subscribe any topic", ssoId);
            return null;
        }

        // 根据主题过滤
        List<String> subscribeClientList = list.stream()
                .filter(e -> e.getTopic().contains(topic))
                .map(MessageTopicSubscribeBo::getClientId)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(subscribeClientList)) {
            log.info("device status message handler with topic, ssoid {} not subscribe topic {}", ssoId, topic);
            return null;
        }

        // 根据客户端信息过滤
        return subscribeClientList;
    }
}
