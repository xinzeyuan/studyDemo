package com.oppo.iot.smarthome.lc.cache;

// cache constants,class,method and so on.