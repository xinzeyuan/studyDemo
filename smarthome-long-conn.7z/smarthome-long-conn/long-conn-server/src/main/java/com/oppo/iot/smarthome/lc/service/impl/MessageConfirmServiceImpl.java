package com.oppo.iot.smarthome.lc.service.impl;

import com.oppo.iot.smarthome.lc.cache.caffeine.CaffeineCacheKeys;
import com.oppo.iot.smarthome.lc.cache.caffeine.CaffeineCacheUtil;
import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import com.oppo.iot.smarthome.lc.enums.MessageConfirmStatusEnum;
import com.oppo.iot.smarthome.lc.service.MessageConfirmService;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * 消息确认处理
 * @author 80279309
 */
@Service
public class MessageConfirmServiceImpl implements MessageConfirmService {

    private static final long DEFAULT_EXPIRE_TIME_IN_SECONDS = 3 * 60;

    @Autowired
    private RedissonClient redissonClient;

    @Override
    public void saveConfirmStatus(String msgId, MessageConfirmStatusEnum statusEnum) {
        RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.SENT_MSG_PREFIX.getKey(msgId));
        msgBucket.set(statusEnum.getCode(), DEFAULT_EXPIRE_TIME_IN_SECONDS, TimeUnit.SECONDS);
    }

    @Override
    public void deleteConfirmStatus(String msgId) {
        RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.SENT_MSG_PREFIX.getKey(msgId));
        msgBucket.delete();
    }

    @Override
    public MessageConfirmStatusEnum getConfirmStatus(String msgId) {
        RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.SENT_MSG_PREFIX.getKey(msgId));
        Integer code = msgBucket.get();
        return code == null ? null : MessageConfirmStatusEnum.getByCode(code);
    }

    @Override
    public int getMessageRetryCount(String msgId, int consumeOrSend) {

        Integer count = null;
        if (consumeOrSend == CONSUME) {
            RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.CONSUME_RETRY_PREFIX.getKey(msgId));
            count = msgBucket.get() == null ? Integer.valueOf(0) : msgBucket.get();
        }
        if (consumeOrSend == SEND) {
            count = CaffeineCacheUtil.sendRetryCount.getIfPresent(CaffeineCacheKeys.SEND_RETRY_PREFIX.getKey(msgId));
        }

        return count == null ? Integer.valueOf(0) : count;
    }

    @Override
    public void setMessageRetryCount(String msgId, int count, int consumeOrSend) {

        if (consumeOrSend == CONSUME) {
            RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.CONSUME_RETRY_PREFIX.getKey(msgId));
            msgBucket.set(count, DEFAULT_EXPIRE_TIME_IN_SECONDS, TimeUnit.SECONDS);
        }
        if (consumeOrSend == SEND) {
            CaffeineCacheUtil.sendRetryCount.put(CaffeineCacheKeys.SEND_RETRY_PREFIX.getKey(msgId), count);
        }

    }

    @Override
    public void deleteMessageRetryCount(String msgId, int consumeOrSend) {
        if (consumeOrSend == CONSUME) {
            RBucket<Integer> msgBucket = redissonClient.getBucket(RedisKeys.CONSUME_RETRY_PREFIX.getKey(msgId));
            msgBucket.delete();
        }
        if (consumeOrSend == SEND) {
            CaffeineCacheUtil.sendRetryCount.invalidate(CaffeineCacheKeys.SEND_RETRY_PREFIX.getKey(msgId));
        }

    }
}
