package com.oppo.iot.smarthome.lc.connector.message.outbound;

import lombok.Data;

/**
 * OTA进度消息
 * @author 80279309
 */
@Data
public class OtaProgressOutMessage extends OutBoundMessage{

    private String deviceId;
    private String target;
    private String status;
    private int percent;
    private String version;
}
