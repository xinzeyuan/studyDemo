package com.oppo.iot.smarthome.lc.connector.message.inbound;

import lombok.Data;

/**
 * 设备事件消息
 * @author 80279309
 */
@Data
public class DeviceEventInMessage extends InboundMessage {
    private String did;
}
