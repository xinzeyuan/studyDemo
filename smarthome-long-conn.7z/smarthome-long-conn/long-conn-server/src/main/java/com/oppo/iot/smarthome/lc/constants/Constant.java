package com.oppo.iot.smarthome.lc.constants;

import java.nio.charset.Charset;

/**
 * @author 80279309
 * @date 2020-09-10
 **/
public class Constant {
    public static final Charset CHARSET_UTF8 = Charset.forName("utf-8");

    public static final String MIN_APP_VERSION = "10800";
}
