package com.oppo.iot.smarthome.lc.util;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.nio.conn.NoopIOSessionStrategy;
import org.apache.http.nio.conn.SchemeIOSessionStrategy;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author 80119490
 * @Date 2018/10/16
 */
public class ApacheAsyncHttpClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApacheAsyncHttpClient.class);

    private static final Integer DEFAULT_CONNECTION_TIMEOUT = 10000;
    private static final Integer DEFAULT_READ_TIMEOUT = 30000;

    private static CloseableHttpAsyncClient HTTP_ASYNC_CLIENT;

    static {
        SSLContext sslContext = null;
        try{
            //默认校验证书
            sslContext = SSLContexts.createSystemDefault();
        }
        catch (Exception ex){
            LOGGER.error("build http ssl context error",ex);
        }

        //检验域名
        HostnameVerifier hostnameVerifier = new DefaultHostnameVerifier();

        IOReactorConfig ioReactorConfig = IOReactorConfig.custom()
                .setIoThreadCount(Runtime.getRuntime().availableProcessors())
                .setConnectTimeout(DEFAULT_CONNECTION_TIMEOUT)
                .setBacklogSize(1024)
                .setRcvBufSize(1024)
                .setSoKeepAlive(true)
                .build();

        Registry<SchemeIOSessionStrategy> sessionStrategyRegistry = RegistryBuilder.<SchemeIOSessionStrategy>create()
                .register("http", NoopIOSessionStrategy.INSTANCE)
                .register("https",new SSLIOSessionStrategy(sslContext,hostnameVerifier)).build();

        try {
            DefaultConnectingIOReactor connectingIOReactor = new  DefaultConnectingIOReactor(ioReactorConfig);
            PoolingNHttpClientConnectionManager connectionManager = new PoolingNHttpClientConnectionManager(connectingIOReactor,sessionStrategyRegistry);
            connectionManager.setMaxTotal(20480);
            connectionManager.setDefaultMaxPerRoute(512);

            RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(DEFAULT_READ_TIMEOUT)
                    .setConnectTimeout(DEFAULT_CONNECTION_TIMEOUT)
                    .setAuthenticationEnabled(false)
                    .setRedirectsEnabled(false)
                    .build();

            HTTP_ASYNC_CLIENT = HttpAsyncClients.custom()
                    .setDefaultRequestConfig(requestConfig)
                    .setConnectionManager(connectionManager)
                    .build();

            HTTP_ASYNC_CLIENT.start();
        } catch (Exception e) {
            LOGGER.error("===================init Http Client failed========================",e);
            Runtime.getRuntime().exit(0);
        }
    }


    public static byte[] execute(String url, String method, Map<String, String> header, byte[] body, Integer connectionTimeout, Integer readTimeOut) {
        HttpResponse response = null;

        InputStream inputStream = null;

        try {
            if(!url.startsWith("http")){
                url = "http://"+url;
            }
            RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();

            RequestBuilder requestBuilder = RequestBuilder.create(method.toUpperCase());

            //连接超时
            if(connectionTimeout != null){
                requestConfigBuilder.setConnectTimeout(connectionTimeout);
            }

            //读取超时
            if(readTimeOut != null){
                requestConfigBuilder.setSocketTimeout(readTimeOut).setConnectionRequestTimeout(readTimeOut);
            }

            if(header != null){
                //维持连接
                header.putIfAbsent("Connection", "keep-alive");

                //填充header
                for(Map.Entry<String, String> entry : header.entrySet()){
                    requestBuilder.addHeader(entry.getKey(),entry.getValue());
                }
            }

            //传输body
            if(body != null){
                HttpEntity httpEntity = new ByteArrayEntity(body);
                requestBuilder.setEntity(httpEntity);
            }

            requestBuilder.setUri(url);

            RequestConfig requestConfig = requestConfigBuilder.build();
            int executeTimeout = requestConfig.getConnectTimeout() + requestConfig.getConnectionRequestTimeout();
            requestBuilder.setConfig(requestConfig);

            Future<HttpResponse> responseFuture = HTTP_ASYNC_CLIENT.execute(requestBuilder.build(),null);

            response = responseFuture.get(executeTimeout , TimeUnit.MILLISECONDS);

            if(response != null){
                HttpEntity entity = response.getEntity();
                if(entity != null && entity.isStreaming()) {
                    inputStream = entity.getContent();
                    if(inputStream != null) {
                        return IOUtils.toByteArray(inputStream);
                    }
                }
                else {
                    LOGGER.warn("=============response info================", response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());
                }
            }

            return null;
        } catch (Exception e) {
            LOGGER.error("fetch http error,url:{}",url,e);
        }
        finally {
            if(inputStream != null){
                IOUtils.closeQuietly(inputStream);
            }
        }
        return null;
    }
}
