import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.junit.Test;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SimpleTest {

    class Demo {
        Integer id;
        String value;

        public Demo(Integer id, String value) {
            this.id = id;
            this.value = value;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof Demo) {
                Demo d = (Demo)obj;
                return this.id.equals(d.id) && this.value.equals(d.value);
            }
            return false;
        }


//        @Override
//        public int hashCode() {
//            return 1;
//        }
    }

    @Test
    public void testHashCodeAndEquals() {
        Demo a = new Demo(1,"aa");
        Demo b = new Demo(1,"aa");

        System.out.println(a == b);
        System.out.println(a.equals(b));
        System.out.println(a.hashCode());
        System.out.println(b.hashCode());


        HashMap<Demo, String> map = new HashMap<>();

        map.put(a, "111");
        map.put(b, "222");

        System.out.println(map);

    }

    @Test
    public void testRemove(){
        HashMap<String, List<String>> map = new HashMap<>();
        map.put("1",List.of("a","b","c"));
        map.put("2",List.of("a","b","c","d"));
        Iterator<Map.Entry<String, List<String>>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, List<String>> entry = iterator.next();
            if (entry.getKey().equals("1")) {
//                iterator.
            }
        }
        System.out.println(map);
    }

    @Test
    public void testUUID() {
        System.out.println(UUID.randomUUID().toString().replaceAll("-", ""));
    }

    @Test
    public void testCaffeineCache() throws InterruptedException {
        Cache<String, Integer> cache = Caffeine.newBuilder()
                .maximumSize(10_000)
                .expireAfterWrite(5, TimeUnit.SECONDS)
                .build();
        cache.put("key1", 100);
        Thread.sleep(3000);
        cache.put("key2", 200);

        System.out.println("key1=" + cache.getIfPresent("key1"));
        System.out.println("key2=" + cache.getIfPresent("key2"));

        Thread.sleep(3000);
        System.out.println("key1=" + cache.getIfPresent("key1"));
        System.out.println("key2=" + cache.getIfPresent("key2"));

        Thread.sleep(3000);
        System.out.println("key1=" + cache.getIfPresent("key1"));
        System.out.println("key2=" + cache.getIfPresent("key2"));

    }
}
