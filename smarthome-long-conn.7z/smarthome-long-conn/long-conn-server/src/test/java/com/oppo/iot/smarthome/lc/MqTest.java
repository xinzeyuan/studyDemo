package com.oppo.iot.smarthome.lc;

import com.oppo.iot.smarthome.lc.cache.redis.RedisKeys;
import com.oppo.iot.smarthome.lc.connector.message.MqTopic;
import com.oppo.iot.smarthome.lc.enums.MessageConfirmStatusEnum;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.junit.Test;
import org.redisson.api.RBucket;
import org.redisson.api.RKeys;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Arrays;

public class MqTest extends TestApplication {

    @Autowired
    MessageTopicSubscribeService messageTopicSubscribeService;
    @Test
    public void testSubscribe() {
        String ssoId="100000";
        String clientId="client100000";
        messageTopicSubscribeService.subscribe(ssoId, clientId, Arrays.asList(MqTopic.DEVICE_STATUS_TOPIC));
    }

    @Autowired
    KafkaTemplate kafkaTemplate;
    @Test
    public void testKafka() {
        String data = "{\n" +
                "  \"deviceId\": \"2JjPdxE\",\n" +
                "  \"properties\": {\n" +
                "    \"power\": \"ON\",\n" +
                "    \"light\": 100\n" +
                "  },\n" +
                "  \"status\": \"1\",\n" +
                "  \"msgId\": \"1244f98218654542bc62736be277592a\",\n" +
                "  \"ssoId\": \"100000\"\n" +
                "}";

        kafkaTemplate.send(MqTopic.DEVICE_STATUS_TOPIC, data).addCallback(new ListenableFutureCallback() {
            @Override
            public void onFailure(Throwable throwable) {
                System.out.println("kafka send fail...");
            }

            @Override
            public void onSuccess(Object o) {
                System.out.println("kafka send success...");
            }
        });
    }


    @Autowired
    DefaultMQProducer mqProducer;
    @Test
    public void testRocketMQ() throws Exception {
        String data = "{\n" +
                "  \"deviceId\": \"2JjPdxE\",\n" +
                "  \"properties\": {\n" +
                "    \"power\": \"ON\",\n" +
                "    \"light\": 100\n" +
                "  },\n" +
                "  \"status\": \"1\",\n" +
                "  \"msgId\": \"1244f98218654542bc62736be277592a\",\n" +
                "  \"ssoId\": \"100000\"\n" +
                "}";

        Message msg = new Message();
        msg.setTopic(MqTopic.DEVICE_STATUS_TOPIC);
        msg.setBody(data.getBytes("UTF-8"));
        mqProducer.send(msg, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                System.out.println("rocketMQ send success...");
            }

            @Override
            public void onException(Throwable e) {
                System.out.println("rocketMQ send fail...");
                e.printStackTrace();
            }
        });
    }

    @Autowired
    RedissonClient redissonClient;
    @Test
    public void testRedissonEnum() {
        RBucket<Object> msgBucket = redissonClient.getBucket(RedisKeys.SENT_MSG_PREFIX.getKey("1244f98218654542bc62736be277592a"));
        Object j = msgBucket.get();
        System.out.println(j);

        RKeys keys = redissonClient.getKeys();
        Iterable<String> keyList = keys.getKeysByPattern("iot:long_conn:sent_msg:*");
        System.out.println(JSONUtils.toJSONString(keyList));
    }

}
