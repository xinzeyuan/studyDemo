package com.oppo.iot.smarthome.lc;




import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.oppo.iot.smarthome.lc.facade.bo.MessageTopicSubscribeBo;
import com.oppo.iot.smarthome.lc.model.UserClient;
import com.oppo.iot.smarthome.lc.service.MessageTopicSubscribeService;
import com.oppo.iot.smarthome.lc.service.UserClientService;
import com.oppo.iot.smarthome.lc.util.JSONUtils;
import org.junit.Test;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class ServiceTest extends TestApplication {



    @Autowired
    UserClientService userClientService;
    @Test
    public void testUserClientService() {
//        UserClient uc = new UserClient();
//        uc.setSsoid("100000");
//        uc.setClientId("client100000");
//        uc.setAppVersion("10600");
//        userClientService.add(uc);

        List<UserClient> list = userClientService.listBySsoId("100001");
        System.out.println(JSONUtils.toJSONString(list));
    }

    @Autowired
    RedissonClient redissonClient;
    @Test
    public void testRedisson() {
        RBucket<String> keyObj = redissonClient.getBucket("test-key-fun");
//        keyObj.set("hello 中国");

        System.out.println(keyObj.get());
    }

    @Autowired
    MessageTopicSubscribeService messageTopicSubscribeService;
    @Test
    public void testSubscribe(){
        ArrayList<String> list = Lists.newArrayList("1", "2", "3","4");
        ArrayList<String> list1 = Lists.newArrayList("1", "2", "3","4","5");
        messageTopicSubscribeService.subscribe("100000","client100000",list);
        messageTopicSubscribeService.subscribe("100000","client100001",list1);
    }

    @Test
    public void testUnSubscribe(){
        ArrayList<String> list = Lists.newArrayList("1", "2","7");
        messageTopicSubscribeService.unsubscribe("100000","client100000",list);
    }

    @Test
    public void testUnSubscribe1(){
        messageTopicSubscribeService.unsubscribe("100000","client100000");
    }
    @Test
    public void testUserTopic(){
        List<MessageTopicSubscribeBo> list = messageTopicSubscribeService.userTopic("100000");
        System.out.println(list);
    }
}
